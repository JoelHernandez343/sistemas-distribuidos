create user hugo@localhost identified by 'hugo';
grant all on servicio_web.* to hugo@localhost;
quit